# rikudo-puzzle-solver
Rikudo puzzle solver implemented in Python as Artificial Intelligence Final Project
